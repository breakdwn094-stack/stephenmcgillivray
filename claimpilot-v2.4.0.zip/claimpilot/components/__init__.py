"""ClaimPilot UI components."""
