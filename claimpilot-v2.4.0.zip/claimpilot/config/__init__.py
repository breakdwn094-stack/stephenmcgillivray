"""ClaimPilot configuration package."""
