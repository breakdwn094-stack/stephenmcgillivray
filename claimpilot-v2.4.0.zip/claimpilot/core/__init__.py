"""ClaimPilot core utilities."""
