# ClaimPilot Refund Policy

**[REFUND POLICY PLACEHOLDER]**

Refund terms to be finalized before public launch.

For questions about refunds, billing, or account issues, contact:
**support@claimpilot.example.com**

---

*This document will be updated with final refund terms prior to the public beta launch.*
