"""ClaimPilot data models."""
