"""ClaimPilot test suite."""
